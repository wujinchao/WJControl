//
//  WJControl.h
//  WJNet
//
//  Created by WJChao on 15/7/29.
//  Copyright (c) 2015年 WJChao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface WJControl : NSObject

#pragma  mark --创建Label
+ (UILabel *)creteLabelWithFrame:(CGRect)frame Font:(int)font Text:(NSString *)text;

#pragma mark -- 创建View
+ (UIView *)viewWithFrame:(CGRect)frame;

#pragma mark -- 创建imageView
+ (UIImageView *)createImageViewWithFrame:(CGRect)frame ImageName:(NSString*)imageName;

#pragma mark -- 创建button
+ (UIButton *)createButtonWithFrame:(CGRect)frame ImageName:(NSString *)imageName Target:(id)target Action:(SEL)action Title:(NSString *)title;


#pragma mark -- 创建UITextField

+ (UITextField *)createTextFieldWithFrame:(CGRect)frame placeholder:(NSString *)placeholder passWord:(BOOL)YESorNO leftImageView:(UIImageView*)imageView rightImageView:(UIImageView *)rightImageView Font:(float)font BackgRoundImageName:(NSString *)imageName;

@end
